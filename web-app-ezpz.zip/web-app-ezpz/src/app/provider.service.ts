import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Serviceprovider } from './provider'; 

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  //url = 'https://gjgxjleioc.execute-api.us-east-2.amazonaws.com/test/serviceprovide';  
 
  constructor(private http: HttpClient) { }  
  getAllProvider(zip: any, category: any): Observable<Serviceprovider[]> {  
     return this.http.get<Serviceprovider[]>('https://7ch5hfkohh.execute-api.us-east-2.amazonaws.com/test/providers?catid='+category +'&zipcd='+zip );  
  }  
}