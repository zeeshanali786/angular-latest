import { TestBed } from '@angular/core/testing';

import { RequestAQuoteService } from './request-a-quote.service';

describe('RequestAQuoteService', () => {
  let service: RequestAQuoteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RequestAQuoteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
