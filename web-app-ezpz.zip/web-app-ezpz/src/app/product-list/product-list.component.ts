import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';  
import { ProviderService } from '../provider.service';  
import { ActivatedRoute } from '@angular/router';
import { Serviceprovider } from '../provider';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  allProviders!: Observable<Serviceprovider[]>;  
  

  constructor(private providerService:ProviderService, private router: ActivatedRoute) { }  

  ngOnInit() {  
   let zip:any = this.router.snapshot.queryParamMap.get('zip'); 
   let category:any = this.router.snapshot.queryParamMap.get('category'); 
    this.loadAllProviders(zip,category);  
  }  

  loadAllProviders(zip: any, category: any) {  
     
    this.allProviders = this.providerService.getAllProvider(zip, category);  
  } 

  share() {
    window.alert('The product has been shared!');
  }
}