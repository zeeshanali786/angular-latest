export class RequestAQuote {     

    constructor(
        public serviceLocation: string = '',
        public dateOfService: string = '',
        public serviceType: string = '',
        public yourProject: string = '',
        public contactEmail: string = '',
        public petsInHome: string = '',
        public availableCalendar: string    
      ) {  }
  }  
  
  