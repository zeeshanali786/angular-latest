import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Category } from './category'; 
import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})

export class CategoryService {
  url = 'https://hxb71r9qs8.execute-api.us-east-2.amazonaws.com/test';  
  data: any;

  constructor(private http: HttpClient, public db: AngularFirestore) { }  
  getAllCategories(): Observable<Category[]> {  
    return this.http.get<Category[]>(this.url );  
  }  

  getAllCategoriesfb(): Observable<any[]> {  
   // return    this.db.list('category').valueChanges(); 
    return this.db.collection('category').snapshotChanges();
  }  
  


}
