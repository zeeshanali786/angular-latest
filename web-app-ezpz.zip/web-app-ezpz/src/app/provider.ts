export class Serviceprovider {  
  serviceProviderID: string | undefined;  
  name!: string;  
  categoryId!: string; 
  fee!: number; 
  serviceZipCode!: string; 
  slogan!: string; 
  rating!: string; 
}  
