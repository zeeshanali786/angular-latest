export class Category {  
  categoryId: string | undefined;  
  name!: string;  
}  




