import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RequestAQuote } from '../request-a-quote';

@Component({
  selector: 'app-request-a-quote',
  templateUrl: './request-a-quote.component.html',
  styleUrls: ['./request-a-quote.component.css']
})
export class RequestAQuoteComponent implements OnInit {

  serviceTypes: string[] = ['Standard', 'Emergency'];

  model = new RequestAQuote('','','','','','','');

  submitted = false;  
  
  constructor() { }

  ngOnInit(): void {
  
  }

  onSubmit()
  {
    this.submitted = true; 
    console.log(this.model);
  }

}
