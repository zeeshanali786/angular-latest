import { Component, OnInit } from '@angular/core';
import { slideInAnimation } from './animations';
import { HttpClient } from '@angular/common/http'; 
import {
  Event,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router
} from '@angular/router';
import { Observable } from 'rxjs';  
import { CategoryService } from './category.service';  

import { Category } from './category';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ],
  animations: [ slideInAnimation ]
})
export class AppComponent implements OnInit  {
  keyword = 'name';
  allCategories: any;
  selectedCategory : any;

  loading = false;

  constructor(private router: Router, private categoryService:CategoryService, private http: HttpClient) {
    this.router.events.subscribe((event: Event) => {
      switch (true) {
        case event instanceof NavigationStart: {
          this.loading = true;
          break;
        }

        case event instanceof NavigationEnd:
        case event instanceof NavigationCancel:
        case event instanceof NavigationError: {
          this.loading = false;
          break;
        }
        default: {
          break;
        }
      }
    });
  }

  ngOnInit() {  
    this.loadAllCategories(); 
  }  

  
  loadAllCategories() {  
     
   // this.allCategories = this.categoryService.getAllCategories();  
   this.categoryService.getAllCategoriesfb().subscribe(data => {
    this.allCategories  = data.map(e => {
      return {
        categoryId: e.payload.doc.id,
        ...e.payload.doc.data()
      } as Category;
    })
  });

  //  this.http.get<any>("https://hxb71r9qs8.execute-api.us-east-2.amazonaws.com/test").subscribe(data => {
  //    this.allCategories = data;});
  } 

  getProviders(zip: any ){

     this.router.navigate(['/providers/'], {
      queryParams: { zip: zip.value, category: this.selectedCategory }
   }); 
  }

  selectEvent(item: any) {   
        this.selectedCategory = item.categoryId;
  }

}