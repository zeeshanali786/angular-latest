import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { RequestAQuote } from './request-a-quote'; 

@Injectable({
  providedIn: 'root'
})
export class RequestAQuoteService {

  constructor() { }

  requstaQuote(RequestAQuote: RequestAQuote) {
    console.log(RequestAQuote);
  }
}
